<template>
    <div id="app">
        <div id="yewei">
    <h1 class="h13">乔泰科技</h1>
    <ul class="ul3">
         <li><a href="#">首页</a></li>
         <li><a href="#">课程专区</a></li>
         <li><a href="#">师资力量</a></li>
         <li><a href="#">超级学习系统</a></li>
         <li><a href="#">学习工具</a></li>
         <li><a href="#">学员专区</a></li>
         <li><a href="#">关于我们</a></li>
        </ul>
    <p class="p1">Copyright © 2019.Company name All rights reserved.More Templates</p>
  </div>
    </div>
</template>

<style lang="scss">
*{margin: 0;padding: 0;}
#yewei{width: 100%; height: 300px;background-color: rgb(2, 37, 18);margin:100px auto auto 0;}
.h13{height: 50px; margin-left: 500px; color: rgba(255, 255, 255, 0.486);padding: 20px;
}
.ul3{display:flex;
justify-content: space-between;
align-items: center;
padding: 15px 320px 0 320px;
li a{
  color: #fff;
  text-decoration: none;
}
}
.p1{
  text-align: center;
  color: #fff;
  position: relative;
  left: 0;
  top: 130px;
}
</style>
