<template>
    <div id="app">
   <el-carousel :interval="4000" type="card" height="500px">
    <el-carousel-item v-for="item5 in list_i" :key="item">
      <h3><img  :src="item5.path" alt=""></h3>
    </el-carousel-item>
  </el-carousel>
  <div class="htt">

<ul class="p5">
  <li v-html="list_kecheng.introduce"></li>
  <li v-html="list_kecheng.project"></li>
  <li><img :src="i+list_kecheng.pic" alt=""></li>
</ul>

  </div>

    </div>
</template>
<script>
export default {
    name:"app",
    data(){
        return {
              imgList1: [
                    {src:'/src/img/1.jpg'},
                    {src:'/src/img/1.jpg'},

      ],
      ii:"",
      h:"<html><body><h1>我是插入的html</h1></body></html>",
      temp:"",
      list_kecheng:[],
      i:'',
      list_i:[],
       open() {
        this.$alert('这是一段内容', '标题名称', {
          confirmButtonText: '确定',
          callback: action => {
            this.$message({
              type: 'info',
              message: `action: ${ action }`
            });
          }
        });
      }

        }
    },methods:{

    },
    mounted(){
              var api='http://www.goodlearn.club/train/index.php/home/api/getCourseById/id/21';
                    this.$http.get(api).then((res)=>{
                        console.log(res);
                         this.temp = eval("("+res.bodyText+")");
                          console.log(this.temp);
                          this.list_kecheng = this.temp.course;
                          console.log(this.temp.rooturl);
                           this.list_i =  this.list_kecheng.pics;
                           console.log(this.list_i);
                           this.i =this.temp.rooturl;
                           this.imgList1.push({src:this.i+this.list_kecheng.pic});
                    },function(err){
                            console.log(err);
                            alert("失败");
                    })
    }


}
</script>
<style lang="scss">
 .box {
    width: 1000px;
     margin: 20px auto;

    .top {
      text-align: center;
    }

    .left7 {
      float: left;
      width: 60px;
    }

    .right7 {
      float: right;
      width: 60px;
    }

    .bottom {
      clear: both;
      text-align: center;
    }

    .item {
      margin: 4px;
    }

    .left7 .el-tooltip__popper,
    .right7 .el-tooltip__popper {
      padding: 8px 10px;
    }
  }
   .el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
    img{height: 500px;width: 750px;}
  }

  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }

  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
  .htt{width: 1095px;}
 .p5{width: 600px; margin:auto;}
</style>